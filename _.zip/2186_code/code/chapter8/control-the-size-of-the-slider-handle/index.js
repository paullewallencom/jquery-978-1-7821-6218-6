
$(function() {

    $( "#treble" ).slider();
    $( "#bass" ).slider();

});
