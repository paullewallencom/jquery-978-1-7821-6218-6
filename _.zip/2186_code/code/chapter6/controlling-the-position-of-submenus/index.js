
$(function() {
    $( "#menu" ).menu({
        position: {
            my: "left top",
            at: "center bottom"
        }
    });
});
