
$(function() {
    $( ".calendar" ).datepicker();
});
