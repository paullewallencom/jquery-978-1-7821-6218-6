
$(function() {
    $( "input" ).datepicker({
        dateFormat: "DD, MM d, yy"
    });
});
