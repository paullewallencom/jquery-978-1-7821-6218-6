
$(function() {
    $( "input" ).datepicker({
        minDate: new Date(),
        maxDate: 14
    });
});
