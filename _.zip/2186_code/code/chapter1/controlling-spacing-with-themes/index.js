
$(function() {

	$( "#accordion" ).accordion();

});
